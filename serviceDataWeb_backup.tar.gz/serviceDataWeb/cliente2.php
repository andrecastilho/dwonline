<?php

include("./webService/lib/nusoap.php");

$params = array(
    "userId" => '1',
    
);

try {

    $client = new SoapClient('http://54.94.199.133/dataWeb/serviceDataWeb/webService/teste.php?wsdl', array('trace' => 1, 'exceptions' => 1));

    $result = $client->__soapCall('getUserInfo', $params);
} catch (SoapFault $e) {



    $result = array(
        'erro' => $e->faultstring
    );
}


var_dump($result);
