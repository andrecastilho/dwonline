<?php
include("./webService/lib/nusoap.php");

$params = array(
    "login" => $_GET['login'],
    "cnpjEmpresa" => $_GET['cnpjEmpresa'],
    "cpf" => $_GET['cpf'],
    "cpf1" => $_GET['cpf1'],
    "cpf2" => $_GET['cpf2'],
);

$params = array('arrConsulta' => $params);
//print_r($params);

try {

    $client = new SoapClient('http://54.94.199.133/dataWeb/serviceDataWeb/webService/index.php?wsdl', array('trace' => 1, 'exceptions' => 1));

    $result = $client->__soapCall('consultaCpf', $params);
} catch (SoapFault $e) {



    $result = array(
        'erro' => $e->faultstring
    );
}
?>
<form action="cpf_1.php" >
    <div>
        <h2>CPF</h2>
        login : Usar 1863597080 - cadastrado para empresa teste
        <input type="text" name="login"><br>
        cnpj empresa - 96335712000130
        <input type="text" name="cnpjEmpresa"><br>
        <input type="text" name="cpf"><br>
        <input type="text" name="cpf1"><br>
        <input type="text" name="cpf2"><br>

        <button type="submit">Buscar</button>
    </div>
    <?php
    $decodado = json_decode($result);


    for ($i = 0; $i < count($decodado); $i++) {

        //echo ">> " . $decodado[$i]->idtb_pessoa_juridica . "<br>";
        //echo ">>ANT " . $idtbAnterior . "<br>";


        if ($decodado[$i]->idtb_pessoa_fisica != $idtbAnterior) {

            echo "<br>ID   :" . ($decodado[$i]->idtb_pessoa_juridica) . "<br>";
            echo "CNPJ :" . ($decodado[$i]->tb_pessoa_fisica_cpf) . "<br>";
            echo "Nome :" . ($decodado[$i]->tb_pessoa_fisica_nome ) . "<br>";
        }

        //for ($a = 0; $a < count($decodado[$i]->tb_pessoa_juridica_fones_fone); $a++) {
        //print_r($decodado[$i]->tb_pessoa_juridica_fones_fone);

        echo "Fone :" . ($decodado[$i]->tb_pessoa_fisica_fones_fone ) . "<br><br><br>";
        //}
        $idtbAnterior = $decodado[$i]->idtb_pessoa_fisica;
    }


    echo "<pre>";
    var_dump($decodado);
    echo "</pre>";

    echo "<pre>";
    var_dump($decodado['erro']);
    echo "</pre>";
    