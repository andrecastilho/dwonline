<?php

include("./webService/lib/nusoap.php");

$params = array(
    "cnpj" => '11445538000126',
    
);

try {

    $client = new SoapClient('http://dwonline.com.br/desenv/serviceDataWeb/webService/index.php?wsdl', array('trace' => 1, 'exceptions' => 1));

    $result = $client->__soapCall('consulta', $params);
} catch (SoapFault $e) {



    $result = array(
        'erro' => $e->faultstring
    );
}


var_dump($result);
